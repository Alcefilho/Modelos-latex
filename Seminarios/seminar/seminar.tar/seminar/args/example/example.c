#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>

extern double rnorm();

int main(int argc, char *argv[]) 
{
  int i, sampleSize;
  double myVar=0.0;

  if (argc != 2) {
    printf("Usage: %s n\ne.g. %s 50 will give a random sample of 50\n", argv[0],argv[0]);
    exit(1);
  }

  sampleSize = strtol(argv[1],(char **)NULL, 10);

  srandom(time(0));
  for (i=0; i<sampleSize; i++) 
  {
    myVar = rnorm(0.0,1.0);
    printf("%f  ", myVar);
    if (!((i+1) % 5)) printf("\n");
  }
  printf("\n");
}


