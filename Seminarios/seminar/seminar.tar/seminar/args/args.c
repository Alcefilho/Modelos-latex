#include <stdio.h>
#include <stdlib.h>

void main(int argc, char **argv)
{
  int i;
  printf("Number of Arguments Passed: %d\n", argc);
  for (i=0; i<argc; i++) {
    printf("argv[%d]: %s\n", i, argv[i]);
  }
  printf("%d in an integer now.\n", atoi(argv[1]));
}
