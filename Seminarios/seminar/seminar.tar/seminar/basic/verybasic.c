/* to make an executable file from this program, use:
  gcc -c verybasic.c
  gcc -o verybasic verybasic.o
  (the executable is named verybasic) */



/* DEFINITIONS, INCLUDES */
#include <stdio.h>
#define N 8



/* FUNCTION PROTOTYPES */
double calcMean(double []);



/* THE main() FUNCTION */
int main()
{
   double myData[N]={0.3,0.5,0.2,0.8,0.2,0.6,0.4,0.5}, theMean;
   theMean = calcMean(myData);
   printf("The mean of the %d observations is: %f\n", N, theMean);
}



/* OTHER FUNCTIONS */
double calcMean (double *data)
{
int i;
double total=0.0;
for (i=0; i<N; i++) {
total += data[i];
}
return(total/N);
}
