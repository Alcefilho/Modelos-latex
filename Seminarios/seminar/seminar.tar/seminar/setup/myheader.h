#include <stdio.h>

/*  Function Prototypes */
int min(int,int);
int max(int,int);
float avg(int,int);

int diff(int, int);
int diffsq(int,int);
int myFunc(int,int);
