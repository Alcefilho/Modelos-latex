#include "myheader.h" 

int max(int num1, int num2)
{
  if (num1 > num2)
    return(num1);
  else
    return(num2);
}

int min(int num1, int num2)
{
  if (num1 > num2)
    return(num1);
  else
    return(num2);
}

float avg(int num1, int num2)
{
  int total;
  float average;
  total = num1+num2;
  average = (float)total/2;
  return(average);
}
