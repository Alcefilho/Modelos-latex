#include <stdio.h>

void main(void) 
{
  printf("\nCalled from main.c ---------------\n");
  printf("The minimum of 4 and 8 is: %d\n", min(4,8));
  printf("The maximum of 4 and 8 is: %d\n", max(4,8));
  printf("The average of 4 and 8 is: %d\n", avg(4,8));
  printf("The difference of 4 and 8 is: %d\n", diff(4,8));
  printf("The squared difference minimum of 4 and 8 is: %d\n", diffsq(4,8));

  function(4,8);
}
