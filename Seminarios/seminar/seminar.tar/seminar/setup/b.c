#include "myheader.h"

int diff(int num1, int num2)
{
  if (num1 > num2)
    return(num1-num2);
  else
    return(num2-num1);
}

int diffsq(int num1, int num2)
{
    return((num1-num2)*(num1-num2));
}

void function(int num1, int num2)
{
  printf("\nCalled from b.c ---------------\n");
  printf("The minimum of 4 and 8 is: %d\n", min(4,8));
  printf("The maximum of 4 and 8 is: %d\n", max(4,8));
  printf("The average of 4 and 8 is: %d\n", avg(4,8));
  printf("The difference of 4 and 8 is: %d\n", diff(4,8));
  printf("The squared difference minimum of 4 and 8 is: %d\n", diffsq(4,8));
}
