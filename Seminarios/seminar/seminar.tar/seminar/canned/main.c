#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <time.h>


extern double rnorm();
extern double pnorm();
extern double qnorm();
extern double gamma(double), gamlog(double);

int main(int argc, char *argv[]) 
{
  int i=0;
  double p=0.0;
  system("clear");

  printf("\nHere is a sample of 10 from N(0,1):\n");
  for(i=0; i<10; i++) {
    printf("%5.3f  ", rnorm(0.0,1.0));
    if((i%5) == 4) printf("\n");
  }

  printf("\nHere is a sample of 20 from N(50,10):\n");
  for(i=0; i<20; i++) {
    printf("%5.4f  ", rnorm(50.0,10.0));
    if((i%5) == 4) printf("\n");
  }

  printf("\nIf X is N(0,1) then P(X < 1.96) = %5.4f\n", pnorm(1.96, 0.0, 1.0));

  printf("\nlogGamma(5) = %8.2f ", gamlog(5.0));
  printf("\n Gamma(10)  = %8.2f \n", gamma(10.0));

}
