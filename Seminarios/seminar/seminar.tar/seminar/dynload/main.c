#include <stdio.h>
#include <math.h>
#include <string.h>

/* compile with:
gcc -c main.c
gcc -o exe main.o ratint.o  -lm
*/

void ratint(double *, double *, int *, double *, double *, double *);

int main(int argc, char **argv)
{
  int i, n=10;
  double a[10], b[10], y=0.0, dy=0.0, x=5.5;

  if(argc > 1)
    x = atof(argv[1]);

  for (i=0; i<10; i++) {
    a[i]=(double)(i+1);
    b[i]=sin(i+1);
  } 
  
  printf("Making a call to: ratint(a, b, &n, &x, &y, &dy)\n", y, dy);
  ratint(a, b, &n, &x, &y, &dy);
  printf("y:%lf dy:%f\n", y, dy);
}
