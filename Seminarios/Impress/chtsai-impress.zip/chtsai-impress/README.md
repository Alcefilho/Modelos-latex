# chtsai-impress

A collection of 16 templates originally made between 2005-2009 for OOo Impress by [Chih-Hao Tsai](http://technology.chtsai.org/impress/). It includes several templates suitable for widescreens.

These are licensed CC-BY-SA (see included license file).
