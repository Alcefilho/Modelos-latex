A sample beamer presentation that allows the generation
of a handout and a presentation version.

