#!/bin/sh
title="PDF Security Options"

# Message Box as Greating
dialog --title "$title" \
       --shadow \
       --msgbox "This script allows you to set permissions and \
password for a PDF file created from a given PostScript file.\n\n \
  - Choose Permissions\n \
  - Enter (mandatory) Owner Password\n \
  - Enter (optional) User Password\n \
  - Use the output command line to create your PDF file." 0 0

# Permission Check-List
permissions=`
  dialog --stdout \
         --title "$title" \
         --shadow \
         --checklist 'Please select features permissions' \
         0 0 0 \
         print       'Print document (normal quality)'           on \
         modify      'Modify contents of document'               on \
         copy        'Copy text and graphics'                    on \
         annotations 'Add/modify annotations'                    on \
         forms       'Fill in interactive form fields'           on \
         extract     'Extract text and graphics (accessibility)' on \
         assemble    'Insert/rotate pages, create bookmarks'     on \
         quality     'Print document (high quality)'             on \
  |
  sed    -e 's/print/4+/'        \
         -e 's/modify/8+/'       \
         -e 's/copy/16+/'        \
         -e 's/annotations/32+/' \
         -e 's/forms/256+/'      \
         -e 's/extract/512+/'    \
         -e 's/assemble/1024+/'  \
         -e 's/quality/2048+/'   \
         -e 's/^/0 3904- /'      \
         -e 's/$/p/'             \
         -e 's/"//g'             \
  |
  dc`

if [ -z "$permissions" ] ; then
  permissions=-4
fi

# Ask for Owner Password
ownerpassword=`
  dialog --stdout \
         --title "$title" \
         --shadow \
	 --passwordbox 'Enter the owner password (mandatory)' 0 0`

# Ask for User Password
userpassword=`
  dialog --stdout \
         --title "$title" \
	 --shadow \
	 --passwordbox 'Enter the user password (optional)' 0 0`

# Output command line
echo -n "ps2pdf14 -sOwnerPassword='$ownerpassword'"
if [ -n "$userpassword" ] ; then
  echo -n " -sUserPassword='$userpassword'"
fi
echo " -dEncryptionR=3 -dKeyLength=128 -dPermissions=$permissions \
in.ps out.pdf"
