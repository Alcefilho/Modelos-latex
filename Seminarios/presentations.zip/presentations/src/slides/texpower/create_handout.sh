#!/bin/sh

sed -e 's/\\usepackage\[display,/\\usepackage\[printout,/' \
	    $1 > $2
