#!/bin/sh

sed -e 's/\\documentclass\[pdf,/\\documentclass\[ps,/' \
	    $1 > $2
