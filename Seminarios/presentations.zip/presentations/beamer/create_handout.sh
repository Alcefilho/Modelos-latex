#!/bin/sh
beamer_has_opts=`grep 'documentclass\[' $1 | wc -l`

if [ "$beamer_has_opts" -gt 0 ] ; then
	sed -e 's/\\documentclass\[/\\documentclass\[handout,dvips,/' \
	    $1 > $2
else
	sed -e 's/\\documentclass/\\documentclass\[handout,dvips\]/' \
	    $1 > $2
fi
